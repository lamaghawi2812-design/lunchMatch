TECH2PEACE SOFTWARE DEVELOPER TRACK - START HERE

1. Read Software_Developer_Track_Instructor_Packet.pdf for the complete teaching plan.
2. Open Software_Developer_Track_Teaching_Slides.pptx for the five teaching days.
3. Complete the preflight in 02_setup_and_tools before participants arrive.
4. Use lunchmatch_starter for demonstrations, guided labs, tests, and the offline backup.
5. Print or share 04_participant_workbook and 05_assessment_rubric.

The DOCX packet is editable in Word and can be imported into Google Docs. Individual DOCX and PDF files are in word_docs and pdfs. The course is designed for beginners who can follow technical language: explain, demonstrate, practice, transfer, and review.
